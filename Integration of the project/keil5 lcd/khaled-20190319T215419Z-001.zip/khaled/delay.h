
#ifndef DELAY_H_
#define DELAY_H_

#include "MCAL.h"

void delayms(float delay) ;

#endif /* DELAY_H_ */
